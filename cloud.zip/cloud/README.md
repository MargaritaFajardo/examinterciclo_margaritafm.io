Este es nuestro peluche estrella
![Imagen de WhatsApp 2025-10-02 a las 11 46 25_1a7d7a5d](https://github.com/user-attachments/assets/7de6beb2-2212-43d9-99b1-7bb4ad14e3d1)
